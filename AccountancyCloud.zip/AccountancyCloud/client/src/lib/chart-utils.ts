import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
} from 'chart.js';

// Register Chart.js components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement
);

export interface ChartData {
  labels: string[];
  datasets: Array<{
    label: string;
    data: number[];
    backgroundColor?: string | string[];
    borderColor?: string | string[];
    borderWidth?: number;
  }>;
}

export interface ChartOptions {
  responsive?: boolean;
  maintainAspectRatio?: boolean;
  plugins?: {
    legend?: {
      display?: boolean;
      position?: 'top' | 'bottom' | 'left' | 'right';
    };
    title?: {
      display?: boolean;
      text?: string;
    };
  };
  scales?: {
    x?: {
      display?: boolean;
      title?: {
        display?: boolean;
        text?: string;
      };
    };
    y?: {
      display?: boolean;
      beginAtZero?: boolean;
      title?: {
        display?: boolean;
        text?: string;
      };
    };
  };
}

// Color palette for consistent chart styling
export const CHART_COLORS = {
  primary: 'hsl(210, 83%, 53%)',
  secondary: 'hsl(210, 40%, 96%)',
  success: 'hsl(142, 71%, 45%)',
  warning: 'hsl(38, 92%, 50%)',
  danger: 'hsl(0, 84%, 60%)',
  info: 'hsl(199, 89%, 48%)',
  light: 'hsl(210, 40%, 98%)',
  dark: 'hsl(222, 84%, 5%)',
  muted: 'hsl(215, 16%, 47%)',
};

export const CHART_COLORS_ARRAY = [
  CHART_COLORS.primary,
  CHART_COLORS.success,
  CHART_COLORS.warning,
  CHART_COLORS.danger,
  CHART_COLORS.info,
  'hsl(291, 64%, 42%)',
  'hsl(31, 81%, 56%)',
  'hsl(338, 77%, 58%)',
];

export function createRevenueChartData(
  months: string[],
  revenueData: number[]
): ChartData {
  return {
    labels: months,
    datasets: [
      {
        label: 'Revenue',
        data: revenueData,
        backgroundColor: 'hsla(210, 83%, 53%, 0.1)',
        borderColor: CHART_COLORS.primary,
        borderWidth: 2,
      },
    ],
  };
}

export function createExpenseChartData(
  categories: string[],
  amounts: number[]
): ChartData {
  return {
    labels: categories,
    datasets: [
      {
        label: 'Expenses',
        data: amounts,
        backgroundColor: CHART_COLORS_ARRAY.slice(0, categories.length),
        borderColor: CHART_COLORS_ARRAY.slice(0, categories.length),
        borderWidth: 1,
      },
    ],
  };
}

export function createCashFlowChartData(
  months: string[],
  inflow: number[],
  outflow: number[]
): ChartData {
  return {
    labels: months,
    datasets: [
      {
        label: 'Cash Inflow',
        data: inflow,
        backgroundColor: 'hsla(142, 71%, 45%, 0.8)',
        borderColor: CHART_COLORS.success,
        borderWidth: 1,
      },
      {
        label: 'Cash Outflow',
        data: outflow,
        backgroundColor: 'hsla(0, 84%, 60%, 0.8)',
        borderColor: CHART_COLORS.danger,
        borderWidth: 1,
      },
    ],
  };
}

export function createProfitLossChartData(
  months: string[],
  revenue: number[],
  expenses: number[]
): ChartData {
  const profit = revenue.map((rev, index) => rev - expenses[index]);
  
  return {
    labels: months,
    datasets: [
      {
        label: 'Revenue',
        data: revenue,
        backgroundColor: 'hsla(210, 83%, 53%, 0.8)',
        borderColor: CHART_COLORS.primary,
        borderWidth: 1,
      },
      {
        label: 'Expenses',
        data: expenses,
        backgroundColor: 'hsla(38, 92%, 50%, 0.8)',
        borderColor: CHART_COLORS.warning,
        borderWidth: 1,
      },
      {
        label: 'Profit',
        data: profit,
        backgroundColor: profit.map(p => 
          p >= 0 ? 'hsla(142, 71%, 45%, 0.8)' : 'hsla(0, 84%, 60%, 0.8)'
        ),
        borderColor: profit.map(p => 
          p >= 0 ? CHART_COLORS.success : CHART_COLORS.danger
        ),
        borderWidth: 1,
      },
    ],
  };
}

export const defaultLineChartOptions: ChartOptions = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      display: true,
      position: 'top',
    },
  },
  scales: {
    x: {
      display: true,
      title: {
        display: true,
        text: 'Month',
      },
    },
    y: {
      display: true,
      beginAtZero: true,
      title: {
        display: true,
        text: 'Amount ($)',
      },
    },
  },
};

export const defaultBarChartOptions: ChartOptions = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      display: true,
      position: 'top',
    },
  },
  scales: {
    x: {
      display: true,
    },
    y: {
      display: true,
      beginAtZero: true,
      title: {
        display: true,
        text: 'Amount ($)',
      },
    },
  },
};

export const defaultDoughnutChartOptions: ChartOptions = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      display: true,
      position: 'right',
    },
  },
};

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
}

export function formatPercentage(value: number): string {
  return `${value.toFixed(1)}%`;
}

export function calculatePercentageChange(
  current: number,
  previous: number
): number {
  if (previous === 0) return current > 0 ? 100 : 0;
  return ((current - previous) / previous) * 100;
}

export function generateMonthLabels(count: number = 6): string[] {
  const labels = [];
  const currentDate = new Date();
  
  for (let i = count - 1; i >= 0; i--) {
    const date = new Date(currentDate);
    date.setMonth(date.getMonth() - i);
    labels.push(date.toLocaleDateString('en-US', { 
      month: 'short',
      year: date.getFullYear() !== currentDate.getFullYear() ? 'numeric' : undefined
    }));
  }
  
  return labels;
}

// Sample data generators for demonstration purposes
export function generateSampleRevenueData(months: number = 6): number[] {
  const baseAmount = 50000;
  return Array.from({ length: months }, (_, i) => {
    const trend = i * 2000; // Growing trend
    const variance = Math.random() * 10000 - 5000; // Random variance
    return Math.max(0, baseAmount + trend + variance);
  });
}

export function generateSampleExpenseData(categories: string[]): number[] {
  return categories.map(() => Math.random() * 25000 + 5000);
}
