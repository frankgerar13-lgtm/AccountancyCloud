import jsPDF from 'jspdf';

export interface InvoiceData {
  invoiceNumber: string;
  issueDate: string;
  dueDate: string;
  client: {
    name: string;
    email?: string;
    address?: string;
    city?: string;
    state?: string;
    zipCode?: string;
  };
  lineItems: Array<{
    description: string;
    quantity: string;
    rate: string;
    amount: string;
  }>;
  subtotal: string;
  taxAmount: string;
  totalAmount: string;
  notes?: string;
  terms?: string;
}

export class PDFGenerator {
  private doc: jsPDF;
  private pageWidth: number;
  private pageHeight: number;
  private margin: number;

  constructor() {
    this.doc = new jsPDF();
    this.pageWidth = this.doc.internal.pageSize.getWidth();
    this.pageHeight = this.doc.internal.pageSize.getHeight();
    this.margin = 20;
  }

  generateInvoicePDF(invoiceData: InvoiceData): Uint8Array {
    // Header
    this.addHeader(invoiceData);
    
    // Company and client info
    this.addCompanyInfo();
    this.addClientInfo(invoiceData);
    
    // Invoice details
    this.addInvoiceDetails(invoiceData);
    
    // Line items table
    this.addLineItemsTable(invoiceData);
    
    // Totals
    this.addTotals(invoiceData);
    
    // Footer with terms and notes
    this.addFooter(invoiceData);
    
    return this.doc.output('arraybuffer') as Uint8Array;
  }

  private addHeader(invoiceData: InvoiceData): void {
    // Company logo area (placeholder)
    this.doc.setFillColor(59, 130, 246); // Primary blue
    this.doc.rect(this.margin, this.margin, 30, 20, 'F');
    
    // Company name
    this.doc.setFontSize(24);
    this.doc.setFont('helvetica', 'bold');
    this.doc.text('FinanceFlow', this.margin + 35, this.margin + 15);
    
    // Invoice title
    this.doc.setFontSize(28);
    this.doc.setFont('helvetica', 'bold');
    this.doc.text('INVOICE', this.pageWidth - this.margin - 60, this.margin + 15);
    
    // Invoice number
    this.doc.setFontSize(12);
    this.doc.setFont('helvetica', 'normal');
    this.doc.text(`Invoice #: ${invoiceData.invoiceNumber}`, this.pageWidth - this.margin - 60, this.margin + 25);
  }

  private addCompanyInfo(): void {
    const startY = this.margin + 50;
    
    this.doc.setFontSize(10);
    this.doc.setFont('helvetica', 'normal');
    
    const companyInfo = [
      'FinanceFlow Inc.',
      '123 Business Street',
      'New York, NY 10001',
      'Phone: (555) 123-4567',
      'Email: billing@financeflow.com'
    ];
    
    companyInfo.forEach((line, index) => {
      this.doc.text(line, this.margin, startY + (index * 5));
    });
  }

  private addClientInfo(invoiceData: InvoiceData): void {
    const startY = this.margin + 50;
    const startX = this.pageWidth / 2;
    
    this.doc.setFontSize(10);
    this.doc.setFont('helvetica', 'bold');
    this.doc.text('Bill To:', startX, startY);
    
    this.doc.setFont('helvetica', 'normal');
    const clientInfo = [
      invoiceData.client.name,
      invoiceData.client.email || '',
      invoiceData.client.address || '',
      [invoiceData.client.city, invoiceData.client.state, invoiceData.client.zipCode]
        .filter(Boolean)
        .join(', ')
    ].filter(line => line.trim() !== '');
    
    clientInfo.forEach((line, index) => {
      this.doc.text(line, startX, startY + 10 + (index * 5));
    });
  }

  private addInvoiceDetails(invoiceData: InvoiceData): void {
    const startY = this.margin + 100;
    
    this.doc.setFontSize(10);
    
    // Issue Date
    this.doc.setFont('helvetica', 'bold');
    this.doc.text('Issue Date:', this.margin, startY);
    this.doc.setFont('helvetica', 'normal');
    this.doc.text(new Date(invoiceData.issueDate).toLocaleDateString(), this.margin + 30, startY);
    
    // Due Date
    this.doc.setFont('helvetica', 'bold');
    this.doc.text('Due Date:', this.margin, startY + 10);
    this.doc.setFont('helvetica', 'normal');
    this.doc.text(new Date(invoiceData.dueDate).toLocaleDateString(), this.margin + 30, startY + 10);
  }

  private addLineItemsTable(invoiceData: InvoiceData): void {
    const startY = this.margin + 130;
    const tableWidth = this.pageWidth - (2 * this.margin);
    const colWidths = {
      description: tableWidth * 0.5,
      quantity: tableWidth * 0.15,
      rate: tableWidth * 0.175,
      amount: tableWidth * 0.175
    };
    
    // Table header
    this.doc.setFillColor(240, 240, 240);
    this.doc.rect(this.margin, startY, tableWidth, 10, 'F');
    
    this.doc.setFontSize(9);
    this.doc.setFont('helvetica', 'bold');
    
    let currentX = this.margin + 2;
    this.doc.text('Description', currentX, startY + 7);
    currentX += colWidths.description;
    this.doc.text('Qty', currentX, startY + 7);
    currentX += colWidths.quantity;
    this.doc.text('Rate', currentX, startY + 7);
    currentX += colWidths.rate;
    this.doc.text('Amount', currentX, startY + 7);
    
    // Table rows
    this.doc.setFont('helvetica', 'normal');
    let currentY = startY + 15;
    
    invoiceData.lineItems.forEach((item, index) => {
      currentX = this.margin + 2;
      
      // Add background for alternating rows
      if (index % 2 === 1) {
        this.doc.setFillColor(250, 250, 250);
        this.doc.rect(this.margin, currentY - 5, tableWidth, 10, 'F');
      }
      
      this.doc.text(item.description, currentX, currentY);
      currentX += colWidths.description;
      this.doc.text(item.quantity, currentX, currentY);
      currentX += colWidths.quantity;
      this.doc.text(`$${parseFloat(item.rate).toFixed(2)}`, currentX, currentY);
      currentX += colWidths.rate;
      this.doc.text(`$${parseFloat(item.amount).toFixed(2)}`, currentX, currentY);
      
      currentY += 10;
    });
    
    // Table border
    this.doc.setDrawColor(200, 200, 200);
    this.doc.rect(this.margin, startY, tableWidth, currentY - startY);
  }

  private addTotals(invoiceData: InvoiceData): void {
    const startY = this.margin + 130 + (invoiceData.lineItems.length * 10) + 30;
    const rightAlign = this.pageWidth - this.margin - 60;
    
    this.doc.setFontSize(10);
    
    // Subtotal
    this.doc.setFont('helvetica', 'normal');
    this.doc.text('Subtotal:', rightAlign, startY);
    this.doc.text(`$${parseFloat(invoiceData.subtotal).toFixed(2)}`, rightAlign + 40, startY);
    
    // Tax
    this.doc.text('Tax:', rightAlign, startY + 10);
    this.doc.text(`$${parseFloat(invoiceData.taxAmount).toFixed(2)}`, rightAlign + 40, startY + 10);
    
    // Total
    this.doc.setFont('helvetica', 'bold');
    this.doc.setFontSize(12);
    this.doc.text('Total:', rightAlign, startY + 25);
    this.doc.text(`$${parseFloat(invoiceData.totalAmount).toFixed(2)}`, rightAlign + 40, startY + 25);
    
    // Line above total
    this.doc.setDrawColor(0, 0, 0);
    this.doc.line(rightAlign, startY + 20, rightAlign + 55, startY + 20);
  }

  private addFooter(invoiceData: InvoiceData): void {
    let currentY = this.pageHeight - 60;
    
    this.doc.setFontSize(9);
    this.doc.setFont('helvetica', 'normal');
    
    if (invoiceData.notes) {
      this.doc.setFont('helvetica', 'bold');
      this.doc.text('Notes:', this.margin, currentY);
      this.doc.setFont('helvetica', 'normal');
      this.doc.text(invoiceData.notes, this.margin, currentY + 8);
      currentY += 20;
    }
    
    if (invoiceData.terms) {
      this.doc.setFont('helvetica', 'bold');
      this.doc.text('Terms:', this.margin, currentY);
      this.doc.setFont('helvetica', 'normal');
      this.doc.text(invoiceData.terms, this.margin, currentY + 8);
    }
  }

  downloadPDF(filename: string): void {
    this.doc.save(filename);
  }

  getPDFBlob(): Blob {
    return this.doc.output('blob');
  }
}

export function generateInvoicePDF(invoiceData: InvoiceData): PDFGenerator {
  const generator = new PDFGenerator();
  generator.generateInvoicePDF(invoiceData);
  return generator;
}

export function downloadInvoicePDF(invoiceData: InvoiceData, filename?: string): void {
  const generator = generateInvoicePDF(invoiceData);
  const finalFilename = filename || `invoice-${invoiceData.invoiceNumber}.pdf`;
  generator.downloadPDF(finalFilename);
}
