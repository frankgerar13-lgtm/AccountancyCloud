import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ArrowDown, ArrowUp, CheckCircle, Upload, RefreshCw } from "lucide-react";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function BankReconciliation() {
  const [selectedBankAccount, setSelectedBankAccount] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");
  const { toast } = useToast();

  const { data: bankAccounts } = useQuery({
    queryKey: ["/api/bank-accounts"],
  });

  const { data: transactions, isLoading } = useQuery({
    queryKey: ["/api/bank-transactions", selectedBankAccount],
    queryFn: () => {
      const url = selectedBankAccount && selectedBankAccount !== "all" 
        ? `/api/bank-transactions?bankAccountId=${selectedBankAccount}`
        : "/api/bank-transactions";
      return fetch(url, { credentials: "include" }).then(res => res.json());
    },
  });

  const reconcileTransactionMutation = useMutation({
    mutationFn: async (transactionId: string) => {
      await apiRequest("PUT", `/api/bank-transactions/${transactionId}/reconcile`);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Transaction reconciled successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/bank-transactions"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to reconcile transaction",
        variant: "destructive",
      });
    },
  });

  const filteredTransactions = transactions?.filter((transaction: any) =>
    transaction.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const unreconciledTransactions = filteredTransactions?.filter((t: any) => !t.isReconciled) || [];
  const reconciledTransactions = filteredTransactions?.filter((t: any) => t.isReconciled) || [];

  const formatCurrency = (amount: string) => {
    const num = parseFloat(amount || '0');
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(num);
  };

  const getTotalBalance = () => {
    if (!filteredTransactions) return 0;
    return filteredTransactions.reduce((sum: number, t: any) => sum + parseFloat(t.amount || '0'), 0);
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground" data-testid="text-bank-reconciliation-title">Bank Reconciliation</h2>
          <p className="text-muted-foreground" data-testid="text-bank-reconciliation-subtitle">Match bank transactions with your accounting records</p>
        </div>
        <div className="flex items-center space-x-3">
          <Button variant="outline" data-testid="button-import-transactions">
            <Upload className="h-4 w-4 mr-2" />
            Import Bank Statement
          </Button>
          <Button data-testid="button-sync-bank-feeds">
            <RefreshCw className="h-4 w-4 mr-2" />
            Sync Bank Feeds
          </Button>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Bank Account</label>
              <Select value={selectedBankAccount} onValueChange={setSelectedBankAccount}>
                <SelectTrigger data-testid="select-bank-account">
                  <SelectValue placeholder="Select bank account" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Accounts</SelectItem>
                  {(bankAccounts && Array.isArray(bankAccounts) ? bankAccounts : [])?.map((account: any) => (
                    <SelectItem key={account.id} value={account.id}>
                      {account.name} - {account.bankName}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">Search Transactions</label>
              <Input
                placeholder="Search by description..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                data-testid="input-search-transactions"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card data-testid="card-total-balance">
          <CardContent className="p-4">
            <div className="text-sm text-muted-foreground">Total Balance</div>
            <div className="text-2xl font-bold" data-testid="text-total-balance">
              {formatCurrency(getTotalBalance().toString())}
            </div>
          </CardContent>
        </Card>
        <Card data-testid="card-unreconciled-count">
          <CardContent className="p-4">
            <div className="text-sm text-muted-foreground">Unreconciled</div>
            <div className="text-2xl font-bold text-orange-600" data-testid="text-unreconciled-count">
              {unreconciledTransactions.length}
            </div>
          </CardContent>
        </Card>
        <Card data-testid="card-reconciled-count">
          <CardContent className="p-4">
            <div className="text-sm text-muted-foreground">Reconciled</div>
            <div className="text-2xl font-bold text-green-600" data-testid="text-reconciled-count">
              {reconciledTransactions.length}
            </div>
          </CardContent>
        </Card>
        <Card data-testid="card-reconciliation-progress">
          <CardContent className="p-4">
            <div className="text-sm text-muted-foreground">Progress</div>
            <div className="text-2xl font-bold" data-testid="text-reconciliation-progress">
              {filteredTransactions?.length ? 
                Math.round((reconciledTransactions.length / filteredTransactions.length) * 100) : 0}%
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Unreconciled Transactions */}
      <Card>
        <CardHeader>
          <CardTitle className="text-orange-600" data-testid="text-unreconciled-title">
            Unreconciled Transactions ({unreconciledTransactions.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="animate-pulse space-y-3" data-testid="loader-unreconciled">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="h-12 bg-muted rounded"></div>
              ))}
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Bank Account</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {unreconciledTransactions.map((transaction: any) => (
                  <TableRow key={transaction.id} data-testid={`row-unreconciled-${transaction.id}`}>
                    <TableCell data-testid={`text-date-${transaction.id}`}>
                      {new Date(transaction.transactionDate).toLocaleDateString()}
                    </TableCell>
                    <TableCell data-testid={`text-description-${transaction.id}`}>
                      {transaction.description}
                    </TableCell>
                    <TableCell>
                      <div className={`font-medium ${
                        parseFloat(transaction.amount) >= 0 ? 'text-green-600' : 'text-red-600'
                      }`} data-testid={`text-amount-${transaction.id}`}>
                        {formatCurrency(transaction.amount)}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        {parseFloat(transaction.amount) >= 0 ? (
                          <ArrowDown className="h-4 w-4 text-green-600" />
                        ) : (
                          <ArrowUp className="h-4 w-4 text-red-600" />
                        )}
                        <span data-testid={`text-type-${transaction.id}`}>
                          {parseFloat(transaction.amount) >= 0 ? 'Credit' : 'Debit'}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell data-testid={`text-bank-account-${transaction.id}`}>
                      {transaction.bankAccount?.name || 'N/A'}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => reconcileTransactionMutation.mutate(transaction.id)}
                        disabled={reconcileTransactionMutation.isPending}
                        data-testid={`button-reconcile-${transaction.id}`}
                      >
                        <CheckCircle className="h-4 w-4 text-green-600" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
                {unreconciledTransactions.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8" data-testid="text-no-unreconciled">
                      <CheckCircle className="h-12 w-12 mx-auto text-green-600 mb-4" />
                      <p className="text-muted-foreground">All transactions are reconciled!</p>
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Reconciled Transactions */}
      {reconciledTransactions.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-green-600" data-testid="text-reconciled-title">
              Reconciled Transactions ({reconciledTransactions.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Reconciled Date</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {reconciledTransactions.slice(0, 10).map((transaction: any) => (
                  <TableRow key={transaction.id} data-testid={`row-reconciled-${transaction.id}`}>
                    <TableCell data-testid={`text-reconciled-date-${transaction.id}`}>
                      {new Date(transaction.transactionDate).toLocaleDateString()}
                    </TableCell>
                    <TableCell data-testid={`text-reconciled-description-${transaction.id}`}>
                      {transaction.description}
                    </TableCell>
                    <TableCell>
                      <div className={`font-medium ${
                        parseFloat(transaction.amount) >= 0 ? 'text-green-600' : 'text-red-600'
                      }`} data-testid={`text-reconciled-amount-${transaction.id}`}>
                        {formatCurrency(transaction.amount)}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        {parseFloat(transaction.amount) >= 0 ? (
                          <ArrowDown className="h-4 w-4 text-green-600" />
                        ) : (
                          <ArrowUp className="h-4 w-4 text-red-600" />
                        )}
                        <span data-testid={`text-reconciled-type-${transaction.id}`}>
                          {parseFloat(transaction.amount) >= 0 ? 'Credit' : 'Debit'}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell data-testid={`text-reconciled-at-${transaction.id}`}>
                      {transaction.reconciledAt ? 
                        new Date(transaction.reconciledAt).toLocaleDateString() : 
                        'N/A'
                      }
                    </TableCell>
                    <TableCell>
                      <Badge variant="default" data-testid={`badge-reconciled-status-${transaction.id}`}>
                        Reconciled
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
