import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Plus, Search, List, Edit, Trash2, FolderOpen, Folder } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import AccountForm from "@/components/accounts/account-form";

export default function ChartOfAccounts() {
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingAccount, setEditingAccount] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const { toast } = useToast();

  const { data: accounts, isLoading } = useQuery({
    queryKey: ["/api/accounts"],
  });

  const filteredAccounts = accounts?.filter((account: any) =>
    account.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    account.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
    account.type.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getAccountTypeVariant = (type: string) => {
    switch (type) {
      case "asset":
        return "default";
      case "liability":
        return "destructive";
      case "equity":
        return "secondary";
      case "revenue":
        return "default";
      case "expense":
        return "outline";
      default:
        return "secondary";
    }
  };

  const getAccountTypeColor = (type: string) => {
    switch (type) {
      case "asset":
        return "text-green-600";
      case "liability":
        return "text-red-600";
      case "equity":
        return "text-blue-600";
      case "revenue":
        return "text-purple-600";
      case "expense":
        return "text-orange-600";
      default:
        return "text-gray-600";
    }
  };

  const formatCurrency = (amount: string) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(parseFloat(amount || '0'));
  };

  const handleEdit = (account: any) => {
    setEditingAccount(account);
    setIsFormOpen(true);
  };

  // Group accounts by type
  const groupedAccounts = filteredAccounts?.reduce((groups: any, account: any) => {
    const type = account.type;
    if (!groups[type]) {
      groups[type] = [];
    }
    groups[type].push(account);
    return groups;
  }, {});

  const accountTypeOrder = ["asset", "liability", "equity", "revenue", "expense"];

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground" data-testid="text-chart-of-accounts-title">Chart of Accounts</h2>
          <p className="text-muted-foreground" data-testid="text-chart-of-accounts-subtitle">Manage your accounting structure and account categories</p>
        </div>
        <Dialog open={isFormOpen} onOpenChange={(open) => {
          setIsFormOpen(open);
          if (!open) setEditingAccount(null);
        }}>
          <DialogTrigger asChild>
            <Button data-testid="button-create-account">
              <Plus className="h-4 w-4 mr-2" />
              Add Account
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle data-testid="text-account-form-title">
                {editingAccount ? "Edit Account" : "Add New Account"}
              </DialogTitle>
            </DialogHeader>
            <AccountForm
              account={editingAccount}
              accounts={accounts || []}
              onSuccess={() => {
                setIsFormOpen(false);
                setEditingAccount(null);
                queryClient.invalidateQueries({ queryKey: ["/api/accounts"] });
              }}
            />
          </DialogContent>
        </Dialog>
      </div>

      {/* Search */}
      <Card>
        <CardContent className="p-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search accounts..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
              data-testid="input-search-accounts"
            />
          </div>
        </CardContent>
      </Card>

      {/* Accounts by Type */}
      {isLoading ? (
        <Card>
          <CardContent className="p-6">
            <div className="animate-pulse space-y-3" data-testid="loader-accounts">
              {[...Array(8)].map((_, i) => (
                <div key={i} className="h-12 bg-muted rounded"></div>
              ))}
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-6">
          {accountTypeOrder.map((type) => {
            const typeAccounts = groupedAccounts?.[type] || [];
            if (typeAccounts.length === 0) return null;

            return (
              <Card key={type}>
                <CardHeader>
                  <CardTitle className={`flex items-center gap-2 ${getAccountTypeColor(type)}`} data-testid={`text-${type}-accounts-title`}>
                    <FolderOpen className="h-5 w-5" />
                    {type.charAt(0).toUpperCase() + type.slice(1)} Accounts ({typeAccounts.length})
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Code</TableHead>
                        <TableHead>Name</TableHead>
                        <TableHead>Sub Type</TableHead>
                        <TableHead>Balance</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {typeAccounts.map((account: any) => (
                        <TableRow key={account.id} data-testid={`row-account-${account.id}`}>
                          <TableCell>
                            <div className="font-mono font-medium" data-testid={`text-account-code-${account.id}`}>
                              {account.code}
                            </div>
                          </TableCell>
                          <TableCell>
                            <div>
                              <div className="font-medium" data-testid={`text-account-name-${account.id}`}>
                                {account.name}
                              </div>
                              {account.description && (
                                <div className="text-sm text-muted-foreground">
                                  {account.description}
                                </div>
                              )}
                            </div>
                          </TableCell>
                          <TableCell data-testid={`text-sub-type-${account.id}`}>
                            {account.subType ? (
                              <Badge variant="outline">
                                {account.subType.replace('_', ' ').toLowerCase()}
                              </Badge>
                            ) : (
                              '-'
                            )}
                          </TableCell>
                          <TableCell>
                            <div className={`font-medium ${
                              parseFloat(account.balance || '0') >= 0 ? 'text-green-600' : 'text-red-600'
                            }`} data-testid={`text-balance-${account.id}`}>
                              {formatCurrency(account.balance)}
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge
                              variant={account.isActive ? "default" : "secondary"}
                              data-testid={`badge-status-${account.id}`}
                            >
                              {account.isActive ? "Active" : "Inactive"}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleEdit(account)}
                                data-testid={`button-edit-${account.id}`}
                              >
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                data-testid={`button-delete-${account.id}`}
                              >
                                <Trash2 className="h-4 w-4 text-red-600" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            );
          })}

          {(!groupedAccounts || Object.keys(groupedAccounts).length === 0) && (
            <Card>
              <CardContent className="text-center py-12" data-testid="text-no-accounts">
                <List className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <p className="text-muted-foreground">No accounts found</p>
              </CardContent>
            </Card>
          )}
        </div>
      )}
    </div>
  );
}
