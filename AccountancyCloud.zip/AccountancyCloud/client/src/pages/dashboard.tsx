import { useQuery } from "@tanstack/react-query";
import MetricsCards from "@/components/dashboard/metrics-cards";
import RevenueChart from "@/components/dashboard/revenue-chart";
import ExpenseChart from "@/components/dashboard/expense-chart";
import { Button } from "@/components/ui/button";
import { Plus, Download, RefreshCw, ArrowDown, AlertTriangle, Info, CheckCircle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { FileText, Receipt, Scale, ShoppingCart, BarChart3 } from "lucide-react";

export default function Dashboard() {
  const { data: metrics, isLoading: metricsLoading } = useQuery({
    queryKey: ["/api/dashboard/metrics"],
  });

  const { data: recentInvoices, isLoading: invoicesLoading } = useQuery({
    queryKey: ["/api/invoices"],
  });

  const { data: bankTransactions, isLoading: transactionsLoading } = useQuery({
    queryKey: ["/api/bank-transactions"],
  });

  return (
    <div className="p-6 space-y-6">
      {/* Dashboard Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground" data-testid="text-dashboard-title">Dashboard</h2>
          <p className="text-muted-foreground" data-testid="text-dashboard-subtitle">Welcome back, get an overview of your business finances</p>
        </div>
        <div className="flex items-center space-x-3">
          <Button variant="secondary" data-testid="button-export">
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
          <Button data-testid="button-new-invoice">
            <Plus className="h-4 w-4 mr-2" />
            New Invoice
          </Button>
        </div>
      </div>

      {/* Key Metrics Cards */}
      <MetricsCards metrics={metrics} isLoading={metricsLoading} />

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <RevenueChart />
        <ExpenseChart />
      </div>

      {/* Recent Activity & Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Recent Invoices */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle data-testid="text-recent-invoices-title">Recent Invoices</CardTitle>
                <Button variant="ghost" size="sm" data-testid="button-view-all-invoices">
                  View All
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {invoicesLoading ? (
                <div className="animate-pulse space-y-3" data-testid="loader-invoices">
                  {[...Array(3)].map((_, i) => (
                    <div key={i} className="h-12 bg-muted rounded"></div>
                  ))}
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-muted/50">
                      <tr>
                        <th className="text-left p-4 text-sm font-medium text-muted-foreground">Invoice #</th>
                        <th className="text-left p-4 text-sm font-medium text-muted-foreground">Client</th>
                        <th className="text-left p-4 text-sm font-medium text-muted-foreground">Amount</th>
                        <th className="text-left p-4 text-sm font-medium text-muted-foreground">Status</th>
                        <th className="text-left p-4 text-sm font-medium text-muted-foreground">Due Date</th>
                      </tr>
                    </thead>
                    <tbody>
                      {recentInvoices?.slice(0, 3).map((invoice: any) => (
                        <tr key={invoice.id} className="border-t border-border hover:bg-muted/30" data-testid={`row-invoice-${invoice.id}`}>
                          <td className="p-4">
                            <span className="font-medium text-foreground" data-testid={`text-invoice-number-${invoice.id}`}>
                              {invoice.invoiceNumber}
                            </span>
                          </td>
                          <td className="p-4">
                            <span className="text-foreground" data-testid={`text-client-name-${invoice.id}`}>
                              {invoice.client?.name || 'N/A'}
                            </span>
                          </td>
                          <td className="p-4">
                            <span className="font-medium text-foreground" data-testid={`text-amount-${invoice.id}`}>
                              ${parseFloat(invoice.totalAmount || '0').toLocaleString()}
                            </span>
                          </td>
                          <td className="p-4">
                            <Badge
                              variant={
                                invoice.status === 'paid' ? 'default' :
                                invoice.status === 'overdue' ? 'destructive' : 'secondary'
                              }
                              data-testid={`badge-status-${invoice.id}`}
                            >
                              {invoice.status}
                            </Badge>
                          </td>
                          <td className="p-4">
                            <span className="text-muted-foreground" data-testid={`text-due-date-${invoice.id}`}>
                              {new Date(invoice.dueDate).toLocaleDateString()}
                            </span>
                          </td>
                        </tr>
                      ))}
                      {(!recentInvoices || recentInvoices.length === 0) && (
                        <tr>
                          <td colSpan={5} className="p-4 text-center text-muted-foreground" data-testid="text-no-invoices">
                            No invoices found
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle data-testid="text-quick-actions-title">Quick Actions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <Button variant="outline" className="w-full justify-start" data-testid="button-create-invoice">
                <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center mr-3">
                  <FileText className="h-4 w-4 text-blue-600" />
                </div>
                Create Invoice
              </Button>
              
              <Button variant="outline" className="w-full justify-start" data-testid="button-add-expense">
                <div className="w-8 h-8 bg-red-100 rounded-lg flex items-center justify-center mr-3">
                  <Receipt className="h-4 w-4 text-red-600" />
                </div>
                Add Expense
              </Button>
              
              <Button variant="outline" className="w-full justify-start" data-testid="button-bank-reconciliation">
                <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center mr-3">
                  <Scale className="h-4 w-4 text-green-600" />
                </div>
                Bank Reconciliation
              </Button>
              
              <Button variant="outline" className="w-full justify-start" data-testid="button-create-po">
                <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center mr-3">
                  <ShoppingCart className="h-4 w-4 text-purple-600" />
                </div>
                Purchase Order
              </Button>
              
              <Button variant="outline" className="w-full justify-start" data-testid="button-generate-report">
                <div className="w-8 h-8 bg-yellow-100 rounded-lg flex items-center justify-center mr-3">
                  <BarChart3 className="h-4 w-4 text-yellow-600" />
                </div>
                Generate Report
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Bank Feeds & Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Recent Bank Transactions */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle data-testid="text-bank-transactions-title">Recent Bank Transactions</CardTitle>
              <Button variant="ghost" size="sm" data-testid="button-sync-bank">
                <RefreshCw className="h-4 w-4 mr-1" />
                Sync Now
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {transactionsLoading ? (
              <div className="animate-pulse space-y-3" data-testid="loader-transactions">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="h-16 bg-muted rounded"></div>
                ))}
              </div>
            ) : (
              <div className="space-y-4">
                {bankTransactions?.slice(0, 3).map((transaction: any) => (
                  <div key={transaction.id} className="flex items-center justify-between p-3 rounded-lg border border-border" data-testid={`card-transaction-${transaction.id}`}>
                    <div className="flex items-center space-x-3">
                      <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                        parseFloat(transaction.amount) > 0 ? 'bg-green-100' : 'bg-red-100'
                      }`}>
                        <ArrowDown className={`h-4 w-4 ${
                          parseFloat(transaction.amount) > 0 ? 'text-green-600' : 'text-red-600'
                        }`} />
                      </div>
                      <div>
                        <p className="font-medium text-foreground" data-testid={`text-transaction-description-${transaction.id}`}>
                          {transaction.description}
                        </p>
                        <p className="text-sm text-muted-foreground" data-testid={`text-transaction-date-${transaction.id}`}>
                          {new Date(transaction.transactionDate).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className={`font-medium ${
                        parseFloat(transaction.amount) > 0 ? 'text-green-600' : 'text-red-600'
                      }`} data-testid={`text-transaction-amount-${transaction.id}`}>
                        {parseFloat(transaction.amount) > 0 ? '+' : ''}${Math.abs(parseFloat(transaction.amount)).toLocaleString()}
                      </p>
                      <p className={`text-xs ${
                        transaction.isReconciled ? 'text-green-600' : 'text-muted-foreground'
                      }`} data-testid={`text-reconciliation-status-${transaction.id}`}>
                        {transaction.isReconciled ? 'Matched' : 'Unmatched'}
                      </p>
                    </div>
                  </div>
                ))}
                {(!bankTransactions || bankTransactions.length === 0) && (
                  <div className="text-center text-muted-foreground py-4" data-testid="text-no-transactions">
                    No recent transactions
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Alerts & Notifications */}
        <Card>
          <CardHeader>
            <CardTitle data-testid="text-alerts-title">Alerts & Notifications</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {metrics?.overdueInvoicesCount > 0 && (
                <div className="flex items-start space-x-3 p-3 rounded-lg bg-orange-50 border border-orange-200" data-testid="alert-overdue-invoices">
                  <div className="w-8 h-8 bg-orange-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <AlertTriangle className="h-4 w-4 text-orange-600" />
                  </div>
                  <div>
                    <p className="font-medium text-foreground" data-testid="text-overdue-count">
                      {metrics.overdueInvoicesCount} Overdue Invoices
                    </p>
                    <p className="text-sm text-muted-foreground">
                      Follow up required
                    </p>
                  </div>
                </div>
              )}
              
              <div className="flex items-start space-x-3 p-3 rounded-lg bg-blue-50 border border-blue-200" data-testid="alert-month-close">
                <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Info className="h-4 w-4 text-blue-600" />
                </div>
                <div>
                  <p className="font-medium text-foreground">Monthly Financial Close</p>
                  <p className="text-sm text-muted-foreground">
                    Due in 3 days - Reconciliation pending
                  </p>
                </div>
              </div>
              
              <div className="flex items-start space-x-3 p-3 rounded-lg bg-green-50 border border-green-200" data-testid="alert-backup-success">
                <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                </div>
                <div>
                  <p className="font-medium text-foreground">System Status</p>
                  <p className="text-sm text-muted-foreground">
                    All systems operational
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

    </div>
  );
}
