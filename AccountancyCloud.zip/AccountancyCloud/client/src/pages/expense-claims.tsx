import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Plus, Search, CreditCard, FileText, CheckCircle, XCircle } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import ExpenseClaimForm from "@/components/expense-claims/expense-claim-form";

export default function ExpenseClaims() {
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const { toast } = useToast();

  const { data: expenseClaims, isLoading } = useQuery({
    queryKey: ["/api/expense-claims"],
  });

  const approveClaimMutation = useMutation({
    mutationFn: async (claimId: string) => {
      await apiRequest("PUT", `/api/expense-claims/${claimId}/approve`, {
        approverId: "current-user-id" // In a real app, this would come from auth context
      });
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Expense claim approved successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/expense-claims"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to approve expense claim",
        variant: "destructive",
      });
    },
  });

  const filteredClaims = expenseClaims?.filter((claim: any) =>
    claim.claimNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
    claim.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
    claim.user?.fullName?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStatusVariant = (status: string) => {
    switch (status) {
      case "approved":
        return "default";
      case "rejected":
        return "destructive";
      case "paid":
        return "secondary";
      default:
        return "outline";
    }
  };

  const formatCurrency = (amount: string) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(parseFloat(amount || '0'));
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground" data-testid="text-expense-claims-title">Expense Claims</h2>
          <p className="text-muted-foreground" data-testid="text-expense-claims-subtitle">Manage employee expense claims and reimbursements</p>
        </div>
        <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
          <DialogTrigger asChild>
            <Button data-testid="button-create-expense-claim">
              <Plus className="h-4 w-4 mr-2" />
              Submit Expense Claim
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle data-testid="text-expense-claim-form-title">Submit New Expense Claim</DialogTitle>
            </DialogHeader>
            <ExpenseClaimForm
              onSuccess={() => {
                setIsFormOpen(false);
                queryClient.invalidateQueries({ queryKey: ["/api/expense-claims"] });
              }}
            />
          </DialogContent>
        </Dialog>
      </div>

      {/* Search */}
      <Card>
        <CardContent className="p-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search expense claims..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
              data-testid="input-search-expense-claims"
            />
          </div>
        </CardContent>
      </Card>

      {/* Expense Claims Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2" data-testid="text-expense-claims-list-title">
            <CreditCard className="h-5 w-5" />
            Expense Claims ({filteredClaims?.length || 0})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="animate-pulse space-y-3" data-testid="loader-expense-claims">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="h-12 bg-muted rounded"></div>
              ))}
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Claim #</TableHead>
                  <TableHead>Employee</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredClaims?.map((claim: any) => (
                  <TableRow key={claim.id} data-testid={`row-expense-claim-${claim.id}`}>
                    <TableCell>
                      <div className="font-medium" data-testid={`text-claim-number-${claim.id}`}>
                        {claim.claimNumber}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div data-testid={`text-employee-name-${claim.id}`}>
                        {claim.user?.fullName || claim.user?.username || 'N/A'}
                      </div>
                      {claim.user?.email && (
                        <div className="text-sm text-muted-foreground">
                          {claim.user.email}
                        </div>
                      )}
                    </TableCell>
                    <TableCell>
                      <div data-testid={`text-description-${claim.id}`}>
                        {claim.description}
                      </div>
                      {claim.receiptUrl && (
                        <div className="flex items-center gap-1 text-sm text-muted-foreground">
                          <FileText className="h-3 w-3" />
                          Receipt attached
                        </div>
                      )}
                    </TableCell>
                    <TableCell data-testid={`text-category-${claim.id}`}>
                      {claim.category || 'General'}
                    </TableCell>
                    <TableCell>
                      <div className="font-medium" data-testid={`text-amount-${claim.id}`}>
                        {formatCurrency(claim.amount)}
                      </div>
                    </TableCell>
                    <TableCell data-testid={`text-expense-date-${claim.id}`}>
                      {new Date(claim.expenseDate).toLocaleDateString()}
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant={getStatusVariant(claim.status)}
                        data-testid={`badge-status-${claim.id}`}
                      >
                        {claim.status.charAt(0).toUpperCase() + claim.status.slice(1)}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        {claim.status === 'submitted' && (
                          <>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => approveClaimMutation.mutate(claim.id)}
                              disabled={approveClaimMutation.isPending}
                              data-testid={`button-approve-${claim.id}`}
                            >
                              <CheckCircle className="h-4 w-4 text-green-600" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              data-testid={`button-reject-${claim.id}`}
                            >
                              <XCircle className="h-4 w-4 text-red-600" />
                            </Button>
                          </>
                        )}
                        {claim.receiptUrl && (
                          <Button
                            variant="ghost"
                            size="sm"
                            data-testid={`button-view-receipt-${claim.id}`}
                          >
                            <FileText className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
                {(!filteredClaims || filteredClaims.length === 0) && (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center py-8" data-testid="text-no-expense-claims">
                      <CreditCard className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                      <p className="text-muted-foreground">No expense claims found</p>
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
