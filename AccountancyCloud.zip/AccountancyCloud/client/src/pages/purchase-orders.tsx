import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Plus, Search, ShoppingCart, Eye, Edit, Trash2 } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import PurchaseOrderForm from "@/components/purchase-orders/purchase-order-form";

export default function PurchaseOrders() {
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingPO, setEditingPO] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const { toast } = useToast();

  const { data: purchaseOrders, isLoading } = useQuery({
    queryKey: ["/api/purchase-orders"],
  });

  const { data: vendors } = useQuery({
    queryKey: ["/api/vendors"],
  });

  const filteredPOs = purchaseOrders?.filter((po: any) =>
    po.poNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
    po.vendor?.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStatusVariant = (status: string) => {
    switch (status) {
      case "received":
        return "default";
      case "cancelled":
        return "destructive";
      default:
        return "secondary";
    }
  };

  const formatCurrency = (amount: string) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(parseFloat(amount || '0'));
  };

  const handleEdit = (po: any) => {
    setEditingPO(po);
    setIsFormOpen(true);
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground" data-testid="text-purchase-orders-title">Purchase Orders</h2>
          <p className="text-muted-foreground" data-testid="text-purchase-orders-subtitle">Manage purchase orders and vendor requests</p>
        </div>
        <Dialog open={isFormOpen} onOpenChange={(open) => {
          setIsFormOpen(open);
          if (!open) setEditingPO(null);
        }}>
          <DialogTrigger asChild>
            <Button data-testid="button-create-purchase-order">
              <Plus className="h-4 w-4 mr-2" />
              Create Purchase Order
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle data-testid="text-purchase-order-form-title">
                {editingPO ? "Edit Purchase Order" : "Create New Purchase Order"}
              </DialogTitle>
            </DialogHeader>
            <PurchaseOrderForm
              purchaseOrder={editingPO}
              vendors={vendors || []}
              onSuccess={() => {
                setIsFormOpen(false);
                setEditingPO(null);
                queryClient.invalidateQueries({ queryKey: ["/api/purchase-orders"] });
              }}
            />
          </DialogContent>
        </Dialog>
      </div>

      {/* Search */}
      <Card>
        <CardContent className="p-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search purchase orders..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
              data-testid="input-search-purchase-orders"
            />
          </div>
        </CardContent>
      </Card>

      {/* Purchase Orders Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2" data-testid="text-purchase-orders-list-title">
            <ShoppingCart className="h-5 w-5" />
            Purchase Orders ({filteredPOs?.length || 0})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="animate-pulse space-y-3" data-testid="loader-purchase-orders">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="h-12 bg-muted rounded"></div>
              ))}
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>PO Number</TableHead>
                  <TableHead>Vendor</TableHead>
                  <TableHead>Order Date</TableHead>
                  <TableHead>Expected Date</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredPOs?.map((po: any) => (
                  <TableRow key={po.id} data-testid={`row-purchase-order-${po.id}`}>
                    <TableCell>
                      <div className="font-medium" data-testid={`text-po-number-${po.id}`}>
                        {po.poNumber}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div data-testid={`text-vendor-name-${po.id}`}>
                        {po.vendor?.name || 'N/A'}
                      </div>
                      {po.vendor?.email && (
                        <div className="text-sm text-muted-foreground">
                          {po.vendor.email}
                        </div>
                      )}
                    </TableCell>
                    <TableCell data-testid={`text-order-date-${po.id}`}>
                      {new Date(po.orderDate).toLocaleDateString()}
                    </TableCell>
                    <TableCell data-testid={`text-expected-date-${po.id}`}>
                      {po.expectedDate ? new Date(po.expectedDate).toLocaleDateString() : 'N/A'}
                    </TableCell>
                    <TableCell>
                      <div className="font-medium" data-testid={`text-total-amount-${po.id}`}>
                        {formatCurrency(po.totalAmount)}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant={getStatusVariant(po.status)}
                        data-testid={`badge-status-${po.id}`}
                      >
                        {po.status.charAt(0).toUpperCase() + po.status.slice(1)}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          data-testid={`button-view-${po.id}`}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleEdit(po)}
                          data-testid={`button-edit-${po.id}`}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          data-testid={`button-delete-${po.id}`}
                        >
                          <Trash2 className="h-4 w-4 text-red-600" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
                {(!filteredPOs || filteredPOs.length === 0) && (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-8" data-testid="text-no-purchase-orders">
                      <ShoppingCart className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                      <p className="text-muted-foreground">No purchase orders found</p>
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
