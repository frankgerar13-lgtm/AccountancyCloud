import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { BarChart3, FileText, Download, Calendar, TrendingUp, DollarSign } from "lucide-react";

export default function Reports() {
  const [reportType, setReportType] = useState("");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [selectedDate, setSelectedDate] = useState("");

  const reports = [
    {
      id: "profit-loss",
      name: "Profit & Loss Statement",
      description: "Revenue and expenses over a period",
      icon: TrendingUp,
      color: "bg-green-100 text-green-600",
      requiresDateRange: true,
    },
    {
      id: "balance-sheet",
      name: "Balance Sheet",
      description: "Assets, liabilities, and equity at a point in time",
      icon: DollarSign,
      color: "bg-blue-100 text-blue-600",
      requiresDateRange: false,
    },
    {
      id: "cash-flow",
      name: "Cash Flow Statement",
      description: "Cash receipts and payments over a period",
      icon: BarChart3,
      color: "bg-purple-100 text-purple-600",
      requiresDateRange: true,
    },
    {
      id: "aged-receivables",
      name: "Aged Receivables",
      description: "Outstanding customer invoices by age",
      icon: FileText,
      color: "bg-orange-100 text-orange-600",
      requiresDateRange: false,
    },
    {
      id: "aged-payables",
      name: "Aged Payables", 
      description: "Outstanding vendor bills by age",
      icon: FileText,
      color: "bg-red-100 text-red-600",
      requiresDateRange: false,
    },
    {
      id: "trial-balance",
      name: "Trial Balance",
      description: "All account balances to verify bookkeeping accuracy",
      icon: BarChart3,
      color: "bg-gray-100 text-gray-600",
      requiresDateRange: false,
    },
  ];

  const selectedReport = reports.find(r => r.id === reportType);

  const generateReport = () => {
    console.log("Generating report:", reportType, { startDate, endDate, selectedDate });
    // This would trigger the actual report generation
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground" data-testid="text-reports-title">Financial Reports</h2>
          <p className="text-muted-foreground" data-testid="text-reports-subtitle">Generate comprehensive financial reports and statements</p>
        </div>
      </div>

      {/* Report Selection */}
      <Card>
        <CardHeader>
          <CardTitle data-testid="text-report-selection-title">Select Report Type</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {reports.map((report) => {
              const Icon = report.icon;
              return (
                <div
                  key={report.id}
                  className={`p-4 border-2 rounded-lg cursor-pointer transition-all ${
                    reportType === report.id 
                      ? 'border-primary bg-primary/5' 
                      : 'border-border hover:border-primary/50'
                  }`}
                  onClick={() => setReportType(report.id)}
                  data-testid={`card-report-${report.id}`}
                >
                  <div className="flex items-start space-x-3">
                    <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${report.color}`}>
                      <Icon className="h-6 w-6" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-foreground" data-testid={`text-report-name-${report.id}`}>
                        {report.name}
                      </h3>
                      <p className="text-sm text-muted-foreground mt-1" data-testid={`text-report-description-${report.id}`}>
                        {report.description}
                      </p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Report Parameters */}
      {selectedReport && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2" data-testid="text-report-parameters-title">
              <Calendar className="h-5 w-5" />
              Report Parameters
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {selectedReport.requiresDateRange ? (
                <>
                  <div>
                    <label className="text-sm font-medium mb-2 block">Start Date</label>
                    <Input
                      type="date"
                      value={startDate}
                      onChange={(e) => setStartDate(e.target.value)}
                      data-testid="input-start-date"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-2 block">End Date</label>
                    <Input
                      type="date"
                      value={endDate}
                      onChange={(e) => setEndDate(e.target.value)}
                      data-testid="input-end-date"
                    />
                  </div>
                </>
              ) : (
                <div>
                  <label className="text-sm font-medium mb-2 block">As of Date</label>
                  <Input
                    type="date"
                    value={selectedDate}
                    onChange={(e) => setSelectedDate(e.target.value)}
                    data-testid="input-selected-date"
                  />
                </div>
              )}
              <div className="flex items-end">
                <Button 
                  onClick={generateReport}
                  disabled={
                    !reportType || 
                    (selectedReport.requiresDateRange && (!startDate || !endDate)) ||
                    (!selectedReport.requiresDateRange && !selectedDate)
                  }
                  className="w-full"
                  data-testid="button-generate-report"
                >
                  <BarChart3 className="h-4 w-4 mr-2" />
                  Generate Report
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Recent Reports */}
      <Card>
        <CardHeader>
          <CardTitle data-testid="text-recent-reports-title">Recent Reports</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 border rounded-lg" data-testid="card-recent-report-1">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                  <TrendingUp className="h-5 w-5 text-green-600" />
                </div>
                <div>
                  <p className="font-medium" data-testid="text-recent-report-name-1">Profit & Loss Statement</p>
                  <p className="text-sm text-muted-foreground">January 1 - December 31, 2024</p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <span className="text-sm text-muted-foreground">Generated 2 days ago</span>
                <Button variant="ghost" size="sm" data-testid="button-download-recent-1">
                  <Download className="h-4 w-4" />
                </Button>
              </div>
            </div>

            <div className="flex items-center justify-between p-3 border rounded-lg" data-testid="card-recent-report-2">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                  <DollarSign className="h-5 w-5 text-blue-600" />
                </div>
                <div>
                  <p className="font-medium" data-testid="text-recent-report-name-2">Balance Sheet</p>
                  <p className="text-sm text-muted-foreground">As of December 31, 2024</p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <span className="text-sm text-muted-foreground">Generated 1 week ago</span>
                <Button variant="ghost" size="sm" data-testid="button-download-recent-2">
                  <Download className="h-4 w-4" />
                </Button>
              </div>
            </div>

            <div className="flex items-center justify-between p-3 border rounded-lg" data-testid="card-recent-report-3">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                  <BarChart3 className="h-5 w-5 text-purple-600" />
                </div>
                <div>
                  <p className="font-medium" data-testid="text-recent-report-name-3">Cash Flow Statement</p>
                  <p className="text-sm text-muted-foreground">Q4 2024</p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <span className="text-sm text-muted-foreground">Generated 2 weeks ago</span>
                <Button variant="ghost" size="sm" data-testid="button-download-recent-3">
                  <Download className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
